const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = 'your_jwt_secret_here'; // Change to env var in production

app.use(cors());
app.use(bodyParser.json());

// Initialize SQLite DB
const db = new sqlite3.Database('./rb.db', (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to SQLite database.');
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )`);
        db.run(`CREATE TABLE IF NOT EXISTS resumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            data TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )`);
    }
});

// Middleware to verify JWT token
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Token missing' });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.user = user;
        next();
    });
}

// Register endpoint
app.post('/api/register', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'Username and password required' });

    bcrypt.hash(password, 10, (err, hash) => {
        if (err) return res.status(500).json({ message: 'Error hashing password' });

        const stmt = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)');
        stmt.run(username, hash, function(err) {
            if (err) {
                if (err.message.includes('UNIQUE')) {
                    return res.status(409).json({ message: 'Username already exists' });
                }
                return res.status(500).json({ message: 'Database error' });
            }
            res.status(201).json({ message: 'User registered successfully' });
        });
        stmt.finalize();
    });
});

// Login endpoint
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'Username and password required' });

    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
        if (err) return res.status(500).json({ message: 'Database error' });
        if (!user) return res.status(401).json({ message: 'Invalid credentials' });

        bcrypt.compare(password, user.password, (err, result) => {
            if (err) return res.status(500).json({ message: 'Error comparing passwords' });
            if (!result) return res.status(401).json({ message: 'Invalid credentials' });

            const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });
            res.json({ token });
        });
    });
});

// Get resume for logged-in user
app.get('/api/resume', authenticateToken, (req, res) => {
    db.get('SELECT data FROM resumes WHERE user_id = ?', [req.user.id], (err, row) => {
        if (err) return res.status(500).json({ message: 'Database error' });
        if (!row) return res.json({ data: null });
        res.json({ data: JSON.parse(row.data) });
    });
});

// Save or update resume for logged-in user
app.post('/api/resume', authenticateToken, (req, res) => {
    const resumeData = JSON.stringify(req.body);
    db.get('SELECT id FROM resumes WHERE user_id = ?', [req.user.id], (err, row) => {
        if (err) return res.status(500).json({ message: 'Database error' });
        if (row) {
            // Update existing
            db.run('UPDATE resumes SET data = ? WHERE user_id = ?', [resumeData, req.user.id], function(err) {
                if (err) return res.status(500).json({ message: 'Database error' });
                res.json({ message: 'Resume updated' });
            });
        } else {
            // Insert new
            db.run('INSERT INTO resumes (user_id, data) VALUES (?, ?)', [req.user.id, resumeData], function(err) {
                if (err) return res.status(500).json({ message: 'Database error' });
                res.json({ message: 'Resume saved' });
            });
        }
    });
});

// Serve frontend static files (optional, if frontend served from backend)
app.use(express.static(path.join(__dirname, '../')));

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
