// Authentication and API integration for RB by vizz

const API_BASE = 'http://localhost:4000/api';

// Check if user is logged in, else redirect to login page
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    window.location.href = 'login.html';
}

// Fetch wrapper with auth header
async function authFetch(url, options = {}) {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }
    options.headers = options.headers || {};
    options.headers['Authorization'] = 'Bearer ' + token;
    const response = await fetch(url, options);
    if (response.status === 401 || response.status === 403) {
        logout();
        return;
    }
    return response;
}

// Load resume data from backend
async function loadResumeFromAPI() {
    const res = await authFetch(`${API_BASE}/resume`);
    if (res && res.ok) {
        const data = await res.json();
        if (data.data) {
            populateForm(data.data);
        }
    }
}

// Save resume data to backend
async function saveResumeToAPI(data) {
    const res = await authFetch(`${API_BASE}/resume`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    });
    if (res && res.ok) {
        alert('Resume saved successfully.');
    } else {
        alert('Failed to save resume.');
    }
}

// Populate form fields with loaded data
function populateForm(data) {
    if (!data) return;
    document.getElementById('full-name').value = data.personal?.fullName || '';
    document.getElementById('email').value = data.personal?.email || '';
    document.getElementById('phone').value = data.personal?.phone || '';
    document.getElementById('address').value = data.personal?.address || '';
    document.getElementById('summary').value = data.personal?.summary || '';

    // Helper to populate entries
    function populateEntries(sectionId, entries, placeholders) {
        const container = document.getElementById(sectionId);
        // Remove all except first entry
        const existingEntries = container.querySelectorAll('.entry');
        existingEntries.forEach((entry, index) => {
            if (index > 0) entry.remove();
        });
        // Fill first entry or add new ones
        entries.forEach((entryData, index) => {
            let entry;
            if (index === 0) {
                entry = container.querySelector('.entry');
            } else {
                entry = container.querySelector('.entry').cloneNode(true);
                container.insertBefore(entry, container.querySelector('button.add-entry'));
            }
            placeholders.forEach(placeholder => {
                const input = entry.querySelector(`[placeholder="${placeholder}"]`);
                if (input) input.value = entryData[placeholder.toLowerCase()] || '';
            });
        });
    }

    populateEntries('education', data.education || [], ['Degree', 'Institution', 'Year']);
    populateEntries('experience', data.experience || [], ['Job Title', 'Company', 'Duration']);
    if (data.experience) {
        const expEntries = document.querySelectorAll('#experience .entry');
        data.experience.forEach((exp, i) => {
            if (expEntries[i]) {
                expEntries[i].querySelector('textarea').value = exp.description || '';
            }
        });
    }
    // Skills
    const skillsContainer = document.getElementById('skills');
    const skillEntries = skillsContainer.querySelectorAll('.entry');
    skillEntries.forEach((entry, i) => {
        if (data.skills && data.skills[i]) {
            entry.querySelector('input').value = data.skills[i];
        } else {
            entry.querySelector('input').value = '';
        }
    });
    if (data.skills && data.skills.length > skillEntries.length) {
        for (let i = skillEntries.length; i < data.skills.length; i++) {
            addEntry('skills');
            const newEntry = skillsContainer.querySelectorAll('.entry')[i];
            newEntry.querySelector('input').value = data.skills[i];
        }
    }
    populateEntries('projects', data.projects || [], ['Project Name', 'Link']);
    if (data.projects) {
        const projEntries = document.querySelectorAll('#projects .entry');
        data.projects.forEach((proj, i) => {
            if (projEntries[i]) {
                projEntries[i].querySelector('textarea').value = proj.description || '';
            }
        });
    }
    populateEntries('certifications', data.certifications || [], ['Certification Name', 'Issuer', 'Year']);
    populateEntries('references', data.references || [], ['Name', 'Position', 'Email', 'Phone']);
    updatePreview();
}

// Add event listener to logout button
document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) return;
    document.getElementById('logout-btn').addEventListener('click', logout);
    loadResumeFromAPI();
});
