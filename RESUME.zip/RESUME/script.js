// Resume Builder Script

document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) return;

    const templateSelector = document.getElementById('template-selector');
    const resumePreview = document.getElementById('resume-preview');
    const exportPdfBtn = document.getElementById('export-pdf');
    const saveResumeBtn = document.getElementById('save-resume');
    const loadResumeBtn = document.getElementById('load-resume');

    // Update preview on input change
    const inputs = document.querySelectorAll('#form-section input, #form-section textarea');
    inputs.forEach(input => {
        input.addEventListener('input', updatePreview);
    });

    // Add entry buttons
    const addEntryButtons = document.querySelectorAll('button.add-entry');
    addEntryButtons.forEach(button => {
        button.addEventListener('click', () => {
            addEntry(button.dataset.section);
        });
    });

    // Remove entry buttons (delegated)
    document.getElementById('form-section').addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-entry')) {
            e.target.parentElement.remove();
            updatePreview();
        }
    });

    // Template selector change
    templateSelector.addEventListener('change', () => {
        const selected = templateSelector.value;
        resumePreview.className = '';
        resumePreview.classList.add('template-' + selected);
    });

    // Export PDF
    exportPdfBtn.addEventListener('click', () => {
        exportToPDF();
    });

    // Save resume to backend API
    saveResumeBtn.addEventListener('click', () => {
        const data = collectFormData();
        saveResumeToAPI(data);
    });

    // Load resume from backend API
    loadResumeBtn.addEventListener('click', () => {
        loadResumeFromAPI();
    });

    // Initialize with default template
    resumePreview.classList.add('template-classic');

    // Initial preview update
    updatePreview();

    function updatePreview() {
        // Personal Info
        document.getElementById('preview-name').textContent = document.getElementById('full-name').value;
        const contact = [];
        if (document.getElementById('email').value) contact.push(document.getElementById('email').value);
        if (document.getElementById('phone').value) contact.push(document.getElementById('phone').value);
        if (document.getElementById('address').value) contact.push(document.getElementById('address').value);
        document.getElementById('preview-contact').textContent = contact.join(' | ');
        document.getElementById('preview-summary').textContent = document.getElementById('summary').value;

        // Education
        const eduContainer = document.getElementById('preview-education');
        eduContainer.innerHTML = '';
        document.querySelectorAll('#education .entry').forEach(entry => {
            const degree = entry.querySelector('input[placeholder="Degree"]').value;
            const institution = entry.querySelector('input[placeholder="Institution"]').value;
            const year = entry.querySelector('input[placeholder="Year"]').value;
            if (degree || institution || year) {
                const div = document.createElement('div');
                div.innerHTML = `<strong>${degree}</strong>, ${institution} (${year})`;
                eduContainer.appendChild(div);
            }
        });

        // Experience
        const expContainer = document.getElementById('preview-experience');
        expContainer.innerHTML = '';
        document.querySelectorAll('#experience .entry').forEach(entry => {
            const title = entry.querySelector('input[placeholder="Job Title"]').value;
            const company = entry.querySelector('input[placeholder="Company"]').value;
            const duration = entry.querySelector('input[placeholder="Duration"]').value;
            const desc = entry.querySelector('textarea').value;
            if (title || company || duration || desc) {
                const div = document.createElement('div');
                div.innerHTML = `<strong>${title}</strong>, ${company} (${duration})<br>${desc}`;
                expContainer.appendChild(div);
            }
        });

        // Skills
        const skillsContainer = document.getElementById('preview-skills');
        skillsContainer.innerHTML = '';
        document.querySelectorAll('#skills .entry input').forEach(input => {
            if (input.value) {
                const span = document.createElement('span');
                span.textContent = input.value;
                skillsContainer.appendChild(span);
            }
        });

        // Projects
        const projContainer = document.getElementById('preview-projects');
        projContainer.innerHTML = '';
        document.querySelectorAll('#projects .entry').forEach(entry => {
            const name = entry.querySelector('input[placeholder="Project Name"]').value;
            const desc = entry.querySelector('textarea').value;
            const link = entry.querySelector('input[placeholder="Link"]').value;
            if (name || desc || link) {
                const div = document.createElement('div');
                let html = `<strong>${name}</strong>`;
                if (link) {
                    html = `<strong><a href="${link}" target="_blank" rel="noopener">${name}</a></strong>`;
                }
                html += `<br>${desc}`;
                div.innerHTML = html;
                projContainer.appendChild(div);
            }
        });

        // Certifications
        const certContainer = document.getElementById('preview-certifications');
        certContainer.innerHTML = '';
        document.querySelectorAll('#certifications .entry').forEach(entry => {
            const name = entry.querySelector('input[placeholder="Certification Name"]').value;
            const issuer = entry.querySelector('input[placeholder="Issuer"]').value;
            const year = entry.querySelector('input[placeholder="Year"]').value;
            if (name || issuer || year) {
                const div = document.createElement('div');
                div.innerHTML = `<strong>${name}</strong>, ${issuer} (${year})`;
                certContainer.appendChild(div);
            }
        });

        // References
        const refContainer = document.getElementById('preview-references');
        refContainer.innerHTML = '';
        document.querySelectorAll('#references .entry').forEach(entry => {
            const name = entry.querySelector('input[placeholder="Name"]').value;
            const position = entry.querySelector('input[placeholder="Position"]').value;
            const email = entry.querySelector('input[placeholder="Email"]').value;
            const phone = entry.querySelector('input[placeholder="Phone"]').value;
            if (name || position || email || phone) {
                const div = document.createElement('div');
                div.innerHTML = `<strong>${name}</strong>, ${position}<br>Email: ${email}<br>Phone: ${phone}`;
                refContainer.appendChild(div);
            }
        });
    }

    function addEntry(section) {
        const container = document.getElementById(section);
        const templateEntry = container.querySelector('.entry');
        if (!templateEntry) return;
        const newEntry = templateEntry.cloneNode(true);
        // Clear inputs in new entry
        newEntry.querySelectorAll('input, textarea').forEach(input => input.value = '');
        container.insertBefore(newEntry, container.querySelector('button.add-entry'));
        updatePreview();
        // Add event listeners to new inputs
        newEntry.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', updatePreview);
        });
        // Add event listener to remove button
        newEntry.querySelector('button.remove-entry').addEventListener('click', () => {
            newEntry.remove();
            updatePreview();
        });
    }

    function saveResume() {
        const data = {};
        // Personal Info
        data.personal = {
            fullName: document.getElementById('full-name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            address: document.getElementById('address').value,
            summary: document.getElementById('summary').value
        };
        // Education
        data.education = [];
        document.querySelectorAll('#education .entry').forEach(entry => {
            data.education.push({
                degree: entry.querySelector('input[placeholder="Degree"]').value,
                institution: entry.querySelector('input[placeholder="Institution"]').value,
                year: entry.querySelector('input[placeholder="Year"]').value
            });
        });
        // Experience
        data.experience = [];
        document.querySelectorAll('#experience .entry').forEach(entry => {
            data.experience.push({
                title: entry.querySelector('input[placeholder="Job Title"]').value,
                company: entry.querySelector('input[placeholder="Company"]').value,
                duration: entry.querySelector('input[placeholder="Duration"]').value,
                description: entry.querySelector('textarea').value
            });
        });
        // Skills
        data.skills = [];
        document.querySelectorAll('#skills .entry input').forEach(input => {
            data.skills.push(input.value);
        });
        // Projects
        data.projects = [];
        document.querySelectorAll('#projects .entry').forEach(entry => {
            data.projects.push({
                name: entry.querySelector('input[placeholder="Project Name"]').value,
                description: entry.querySelector('textarea').value,
                link: entry.querySelector('input[placeholder="Link"]').value
            });
        });
        // Certifications
        data.certifications = [];
        document.querySelectorAll('#certifications .entry').forEach(entry => {
            data.certifications.push({
                name: entry.querySelector('input[placeholder="Certification Name"]').value,
                issuer: entry.querySelector('input[placeholder="Issuer"]').value,
                year: entry.querySelector('input[placeholder="Year"]').value
            });
        });
        // References
        data.references = [];
        document.querySelectorAll('#references .entry').forEach(entry => {
            data.references.push({
                name: entry.querySelector('input[placeholder="Name"]').value,
                position: entry.querySelector('input[placeholder="Position"]').value,
                email: entry.querySelector('input[placeholder="Email"]').value,
                phone: entry.querySelector('input[placeholder="Phone"]').value
            });
        });
        localStorage.setItem('resumeData', JSON.stringify(data));
        alert('Resume saved locally.');
    }

    function loadResume() {
        const data = JSON.parse(localStorage.getItem('resumeData'));
        if (!data) {
            alert('No saved resume found.');
            return;
        }
        // Personal Info
        document.getElementById('full-name').value = data.personal.fullName || '';
        document.getElementById('email').value = data.personal.email || '';
        document.getElementById('phone').value = data.personal.phone || '';
        document.getElementById('address').value = data.personal.address || '';
        document.getElementById('summary').value = data.personal.summary || '';

        // Helper to populate entries
        function populateEntries(sectionId, entries, placeholders) {
            const container = document.getElementById(sectionId);
            // Remove all except first entry
            const existingEntries = container.querySelectorAll('.entry');
            existingEntries.forEach((entry, index) => {
                if (index > 0) entry.remove();
            });
            // Fill first entry or add new ones
            entries.forEach((entryData, index) => {
                let entry;
                if (index === 0) {
                    entry = container.querySelector('.entry');
                } else {
                    entry = container.querySelector('.entry').cloneNode(true);
                    container.insertBefore(entry, container.querySelector('button.add-entry'));
                }
                placeholders.forEach(placeholder => {
                    const input = entry.querySelector(`[placeholder="${placeholder}"]`);
                    if (input) input.value = entryData[placeholder.toLowerCase()] || '';
                });
            });
        }

        // Education
        populateEntries('education', data.education || [], ['Degree', 'Institution', 'Year']);
        // Experience
        populateEntries('experience', data.experience || [], ['Job Title', 'Company', 'Duration']);
        // Fill descriptions separately for experience
        if (data.experience) {
            const expEntries = document.querySelectorAll('#experience .entry');
            data.experience.forEach((exp, i) => {
                if (expEntries[i]) {
                    expEntries[i].querySelector('textarea').value = exp.description || '';
                }
            });
        }
        // Skills
        const skillsContainer = document.getElementById('skills');
        const skillEntries = skillsContainer.querySelectorAll('.entry');
        skillEntries.forEach((entry, i) => {
            if (data.skills && data.skills[i]) {
                entry.querySelector('input').value = data.skills[i];
            } else {
                entry.querySelector('input').value = '';
            }
        });
        // Add more skill entries if needed
        if (data.skills && data.skills.length > skillEntries.length) {
            for (let i = skillEntries.length; i < data.skills.length; i++) {
                addEntry('skills');
                const newEntry = skillsContainer.querySelectorAll('.entry')[i];
                newEntry.querySelector('input').value = data.skills[i];
            }
        }
        // Projects
        populateEntries('projects', data.projects || [], ['Project Name', 'Link']);
        if (data.projects) {
            const projEntries = document.querySelectorAll('#projects .entry');
            data.projects.forEach((proj, i) => {
                if (projEntries[i]) {
                    projEntries[i].querySelector('textarea').value = proj.description || '';
                }
            });
        }
        // Certifications
        populateEntries('certifications', data.certifications || [], ['Certification Name', 'Issuer', 'Year']);
        // References
        populateEntries('references', data.references || [], ['Name', 'Position', 'Email', 'Phone']);

        updatePreview();
        alert('Resume loaded from local storage.');
    }

    async function exportToPDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Simple approach: export the preview section as text
        // For better formatting, a library like html2canvas or advanced jsPDF usage is needed
        // Here, we export text content with basic formatting

        let y = 10;
        const lineHeight = 10;
        const pageHeight = doc.internal.pageSize.height;

        function addText(text, options = {}) {
            const { fontSize = 12, fontStyle = 'normal' } = options;
            doc.setFontSize(fontSize);
            doc.setFont(undefined, fontStyle);
            const splitText = doc.splitTextToSize(text, 180);
            splitText.forEach(line => {
                if (y > pageHeight - 20) {
                    doc.addPage();
                    y = 10;
                }
                doc.text(line, 10, y);
                y += lineHeight;
            });
        }

        // Header
        addText(document.getElementById('preview-name').textContent, { fontSize: 22, fontStyle: 'bold' });
        addText(document.getElementById('preview-contact').textContent, { fontSize: 12, fontStyle: 'normal' });
        y += 5;

        // Summary
        addText('Professional Summary', { fontSize: 16, fontStyle: 'bold' });
        addText(document.getElementById('preview-summary').textContent);

        // Sections helper
        function addSection(title, containerId) {
            const container = document.getElementById(containerId);
            if (!container || container.children.length === 0) return;
            addText(title, { fontSize: 16, fontStyle: 'bold' });
            Array.from(container.children).forEach(child => {
                addText(child.textContent);
            });
            y += 5;
        }

        addSection('Education', 'preview-education');
        addSection('Work Experience', 'preview-experience');
        addSection('Skills', 'preview-skills');
        addSection('Projects', 'preview-projects');
        addSection('Certifications', 'preview-certifications');
        addSection('References', 'preview-references');

        doc.save('resume.pdf');
    }

    function collectFormData() {
        const data = {};
        // Personal Info
        data.personal = {
            fullName: document.getElementById('full-name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            address: document.getElementById('address').value,
            summary: document.getElementById('summary').value
        };
        // Education
        data.education = [];
        document.querySelectorAll('#education .entry').forEach(entry => {
            data.education.push({
                degree: entry.querySelector('input[placeholder="Degree"]').value,
                institution: entry.querySelector('input[placeholder="Institution"]').value,
                year: entry.querySelector('input[placeholder="Year"]').value
            });
        });
        // Experience
        data.experience = [];
        document.querySelectorAll('#experience .entry').forEach(entry => {
            data.experience.push({
                title: entry.querySelector('input[placeholder="Job Title"]').value,
                company: entry.querySelector('input[placeholder="Company"]').value,
                duration: entry.querySelector('input[placeholder="Duration"]').value,
                description: entry.querySelector('textarea').value
            });
        });
        // Skills
        data.skills = [];
        document.querySelectorAll('#skills .entry input').forEach(input => {
            data.skills.push(input.value);
        });
        // Projects
        data.projects = [];
        document.querySelectorAll('#projects .entry').forEach(entry => {
            data.projects.push({
                name: entry.querySelector('input[placeholder="Project Name"]').value,
                description: entry.querySelector('textarea').value,
                link: entry.querySelector('input[placeholder="Link"]').value
            });
        });
        // Certifications
        data.certifications = [];
        document.querySelectorAll('#certifications .entry').forEach(entry => {
            data.certifications.push({
                name: entry.querySelector('input[placeholder="Certification Name"]').value,
                issuer: entry.querySelector('input[placeholder="Issuer"]').value,
                year: entry.querySelector('input[placeholder="Year"]').value
            });
        });
        // References
        data.references = [];
        document.querySelectorAll('#references .entry').forEach(entry => {
            data.references.push({
                name: entry.querySelector('input[placeholder="Name"]').value,
                position: entry.querySelector('input[placeholder="Position"]').value,
                email: entry.querySelector('input[placeholder="Email"]').value,
                phone: entry.querySelector('input[placeholder="Phone"]').value
            });
        });
        return data;
    }
});
