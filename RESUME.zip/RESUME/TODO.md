# Resume Builder Web App - TODO List

- [x] Create index.html: Main page structure with form sections (personal info, education, experience, skills, projects, certifications), preview area, and control buttons (export PDF, save, load, template selector)
- [x] Create styles.css: Responsive design, multiple resume templates (e.g., Classic, Modern, Minimalist), form styling, and preview layout
- [x] Create script.js: Implement dynamic form handling, live preview updates, add/remove section entries, save/load functionality using localStorage, PDF export with jsPDF, template switching
- [ ] Test the app: Open index.html in browser, verify all features (input forms, preview, export, save/load, templates), ensure responsiveness
- [ ] Setup backend with Node.js, Express, JWT auth, SQLite database
- [ ] Implement login and registration API endpoints
- [ ] Implement resume CRUD API endpoints linked to authenticated users
- [ ] Update frontend for login/logout, API integration, and premium UI/UX
- [ ] Ensure mobile compatibility and modern futuristic design
